## Enchanting ##

##### A mod adding a Minecraft-inspired Enchantment Table to Minetest. #####
##### 3 enchants are proposed for the default tools, and 2 enchants for the armors from [3d_armor](https://github.com/stujones11/minetest-3d_armor). #####

##### This mod is originating from [X-Decor](https://github.com/kilbith/xdecor). #####

![Preview](https://lut.im/oWfKNfxAA4/n9jqwFpJOdUdo8yT.png)
![Preview2](http://i.imgur.com/X9MkQzV.png)
