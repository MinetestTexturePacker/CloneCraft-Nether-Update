minetest-glow
=============

Adds 2 glowing blocks for minetest:
Glowing stone and glowing lantern.
