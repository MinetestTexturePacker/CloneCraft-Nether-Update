Wielditem mod
==============
By Kaadmy, for Pixture

Shows the wield item in 3rd person view

Source license: LGPLv2.1
