A 3d character model re-texturing api used as the framework for this modpack.

depends: 3d_armor

Originally a part of 3d_armor, shields have been re-included as an optional extra.
If you do not what shields then simply remove the shields folder from the modpack.
