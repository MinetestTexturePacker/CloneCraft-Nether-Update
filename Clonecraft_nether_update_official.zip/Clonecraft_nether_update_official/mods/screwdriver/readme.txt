Minetest mod: screwdriver
=========================

License of source code:
-----------------------
Copyright (C) 2013 RealBadAngel, Maciej Kasatkin <mk@realbadangel.pl>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-2.1.html

License of media (textures and sounds)
--------------------------------------
Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)                                 
http://creativecommons.org/licenses/by-sa/3.0/

Created by Gambit (WTFPL):
  screwdriver.png