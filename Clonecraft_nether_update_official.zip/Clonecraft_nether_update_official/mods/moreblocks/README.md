More Blocks
===========

More Blocks for Minetest <http://minetest.net>, a free/libre infinite
world block sandbox game.

To install, just clone this repository into your "mods" directory.

More Blocks code is licensed under the zlib license, textures are by Calinou and are licensed under CC BY-SA 3.0 Unported.

moreblocks_copperpatina.png is by pithydon licensed under CC0 1.0

**Forum topic:** <https://forum.minetest.net/viewtopic.php?f=11&t=509>
